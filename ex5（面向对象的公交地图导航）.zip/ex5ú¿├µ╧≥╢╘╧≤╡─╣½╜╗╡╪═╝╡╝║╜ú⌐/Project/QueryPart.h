#pragma once

#include <QWidget>
#include "ui_QueryPart.h"
class confirm;
class QueryPart : public QWidget
{
	Q_OBJECT

public:
	QueryPart(QWidget *parent = Q_NULLPTR);
	~QueryPart();
	QGraphicsView* parnt;
	void myShow(QGraphicsView* p);
private:
	Ui::QueryPart ui;
	QGraphicsView* graphicsView;
private slots:
	void Query();
	void openFile();
};
