#include "QueryPart.h"
#include <QFileDialog>
#include <QMessageBox>
#include "logiclayer.h"
#include "MAP.h"
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <QGraphicsSceneMouseEvent>
#include<QDebug>
using std::string;
using namespace std;

struct node_ {
    char name[50];
    int x, y;
};

QueryPart::QueryPart(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	connect(ui.doneBtn, SIGNAL(clicked()), this, SLOT(Query()), Qt::UniqueConnection);
    connect(ui.flBtn, SIGNAL(clicked()), this, SLOT(openFile()), Qt::UniqueConnection);
}
void QueryPart::myShow(QGraphicsView* p) {
	parnt = p;
	show();
}

int max(int a, int b)
{
    return a > b?a:b;
}
int getLCS(string s, string t) {
    if (s.empty() || t.empty()) {
        return 0;
    }
    int l1 = s.length();
    int l2 = t.length();
    int res = 0;
    for (int i = 0; i < l1; i++) {
        for (int j = 0; j < l2; j++) {
            int m = i;
            int k = j;
            int len = 0;
            while (m < l1 && k < l2 && s.at(m) == t.at(k)) {
                len++;
                m++;
                k++;
            }
            res = max(res, len);
        }
    }
    return res;
}

void QueryPart::openFile() {
    ui.labelHits->setText("");
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"), ".", tr("*.txt"));
    ui.textEdit_fl->setText(fileName);
}

void QueryPart::Query() {
    int flag1 = 0,flag2 = 0;
    QString  fs = ui.textEdit_fl->toPlainText();
    if (fs.isEmpty()) {
        ui.labelHits->setText(QString::fromLocal8Bit("������ʾ��û�����뵥λ���ļ�·����"));
        ui.textEdit_fl->setFocus();
        return;
    }


    // ���������ļ��������infile
    ifstream infile(fs.toStdString().c_str(), ios::in);

    if (!infile)
    { // �ж��ļ��Ƿ����
        cerr << "open error." << endl;
        exit(1); // �˳�����
    }

    char str[255]; // �����ַ������������ܶ�ȡһ�е�����
    node_* n = new node_[10];
    int num = 0;
    while (infile)
    {
        int j = 0;
        int x1, x2, x3, y1, y2, y3;
        infile.getline(str, 255); // getline�������Զ�ȡ���в�������str������
        for (;; j++)
        {
            if (str[j] == ' ')break;
        }
        memcpy(n[num].name, str, j);
        n[num].name[j] = '\0';
        for (;; j++)
        {
            if (str[j] != ' ')break;
        }
        j++;
        x1 = str[j++] - '0';
        x2 = str[j++] - '0';
        x3 = str[j++] - '0';
        j += 2;
        y1 = str[j++] - '0';
        y2 = str[j++] - '0';
        y3 = str[j++] - '0';
        n[num].x = x1 * 100 + x2 * 10 + x3;
        n[num].y = y1 * 100 + y2 * 10 + y3;
        num++;
    }   
    string t;
    int res=0;
    int y;
    int i1, i2;
	QString start_ = ui.textEdit_start->toPlainText();
    string start = start_.toStdString();
    for (int i = 0; i <num-1 ; i++) {
        t = n[i].name;
        y = getLCS(t, start);
        if (y > res) { 
            res = y, i1 = i; 
        }
    }
    if ((res/3) < 3)
    {
        ui.labelHits->setText(QString::fromLocal8Bit("������ʾ�����û���ʺϵĵ�λ��"));
        return;
    }
    else
    {
        flag1 = 1;
    }
    res = 0;
	string end_ = ui.textEdit_end->toPlainText().toStdString();
    for (int i = 0; i < num - 1; i++) {
        t = n[i].name;
        y = getLCS(t, end_);
        if (y > res)   res = y,i2=i;
    }
    if (res/3 < 3)
    {
        ui.labelHits->setText(QString::fromLocal8Bit("������ʾ���յ�û���ʺϵĵ�λ��"));
        return;
    }
    else
    {
        flag2 = 1;
    }
    if (flag1 == 1 && flag2 == 1) {
        if (gis == nullptr)
        {
            ui.labelHits->setText(QString::fromLocal8Bit("������վ�����·�ļ�"));
            return;
        }
        
               ((MyScene*)(parnt->scene()))->clickmouse(n[i1].x, n[i1].y, 1);
        ((MyScene*)(parnt->scene()))->clickmouse(n[i2].x, n[i2].y, 2);
        close();
        
    }
}


QueryPart::~QueryPart()
{
}
